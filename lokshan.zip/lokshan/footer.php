			<div class="footer_area">
				<div class="footer_image" style="background-image: url();">
					<div class="footer fix">
						<div class="row">
						
						<?php dynamic_sidebar('footer_widget'); ?>
						</div>
					</div>
				</div>
				<div class="copy_right fix">
					<div class="row fix">
						<div class=" fix right col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<span><?php global $Lokshan; echo $Lokshan['copy_right_text']; ?></span>
						</div>
						<div class=" fix warning col-lg-6 col-md-6 col-sm-12 col-xs-12">

						<span><?php $Lokshan; echo $Lokshan['warning_text_change']; ?></span>
						</div>
						<div class=" fix developer col-lg-12 col-md-12 col-sm-12 col-xs-12">

						<center><span>Design & Developed by <a href="http://www.shossain.org">Softuron International </a></span></center>
						</div>
					</div>

				</div>
			</div>
		</div>
		<?php wp_footer(); ?>
	</body>
</html>
