<!DOCTYPE html >

<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo('charset');?>">
                <meta name="viewport" content="width-device-width, initial-scale=1.0">



		
		<?php wp_head(); ?>
	</head>

	<body <?php body_class(); ?>>
		<div class="markup fix">
			<div class="date fix">
				<center>
					<i class="fa fa-calendar-plus-o" aria-hidden="true"></i><span> 	<?php echo do_shortcode('[english_date]'); ?>  </span> <i class="fa fa-calendar-plus-o" aria-hidden="true"></i><span><?php echo do_shortcode('[bangla_day]'); ?> </span><i class="fa fa-calendar-plus-o" aria-hidden="true"></i><span> <?php echo do_shortcode('[bangla_date]'); ?> </span><!--<i style="margin-left:3px;" class="fa fa-clock-o" aria-hidden="true"></i><span style="margin-left:5px;"><?php //echo do_shortcode('[bangla_time]'); ?> ( ঢাকা )</span>-->
				</center>
				
			</div>
			<div class="header ">
				<div class="row ">
					<div  class="fix logo col-lg-6 col-md-6 col-sm-12 col-xs-12">

                                               <div class="fix"style=""> <p style="font-size:14px;width:100%; margin-top:15px;text-align:left;margin-left:-60px;">শানিত মগজের ডাক</p>
					 	<!--<a href="<?php //bloginfo('home'); ?>"><img src="<?php //global $Lokshan ; echo $Lokshan['logo_change']['url']; ?>" alt="Lokshan"/></a>-->
					 	<a href="<?php bloginfo('home'); ?>"><h1 style="margin-top:-15px;"><span><?php global $Lokshan ; echo $Lokshan['fitst_text_change']; ?></span><span><?php echo $Lokshan['second_text_change']; ?></span><span><?php echo $Lokshan['third_text_change']; ?></span><span><?php echo $Lokshan['fourth_text_change']; ?></span><span><?php echo $Lokshan['fifth_text_change']; ?></span><span><?php echo $Lokshan['sixth_text_change']; ?></span><span><?php echo $Lokshan['seventh_text_change']; ?></span><span><?php echo $Lokshan['eighth_text_change']; ?></span></h1></div>
					 	<p><?php echo $Lokshan['title_link_change']; ?></p></a>

					</div>
					<div  class=" header-add col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<img src="<?php echo $Lokshan['change_header_add']['url']; ?>" alt="ADD"/>
					</div>
				</div>

                                <div class="row">
				<div class="main_menu col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<center>
				
										<?php 
											if(function_exists('wp_nav_menu')){
												wp_nav_menu(array(
													'theme_location' => 'main-menu'
												));
											}
										?>
				</center>
				</div>
                                </div>
			</div>
				<div class="row scrollbar ">
					<div class="scrollbar_title  col-lg-2 col-md-2 col-sm-2 col-xs-6">
						<span>শিরোনাম</span>
					</div>
					<div class="scroll  col-lg-10 col-md-10 col-sm-10 col-xs-6">
					
						<marquee>
						<?php 
						
								$scroll_title = new WP_Query(array(
									'post_type'=> 'post',
									'posts_per_page'=> 4,
								));
						while( $scroll_title->have_posts()) :$scroll_title->the_post(); ?>
						<span></span><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
<?php the_title();?>
						<?php endwhile; ?>
						</marquee>
						
					</div>
				</div>
				