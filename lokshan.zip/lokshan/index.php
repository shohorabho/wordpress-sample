<?php 
get_header();
?>

				<div class="row">
					<div class="content col-lg-8 col-md-8 col-sm-12 col-xs-12">
						<div class="row width_ninty_eight fix">
							<div class="update col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<div class="row">
									<div class="post_heading col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center>
											<h1>সাম্প্রতিক সংযুক্তি</h1>
										</center>
									</div>
								</div>
								<div class=" home_post">
								
								<?php 
								$Recent = new WP_Query(array(
									'post_type'=> 'post',
									'posts_per_page'=> 4,
								));
								while($Recent->have_posts()) : $Recent->the_post();
								?>
								
									<a href="<?php the_permalink(); ?>">
										<div class="post_content fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<figure><?php the_post_thumbnail();?></figure>
											<h2><?php the_title(); ?> </h2>
											<h4><?php the_time(' d F Y '); ?>  | <?php the_time(' g:i a '); ?> </h4>
											<h5><?php the_field('author'); ?></h5>
											<p><?php read_more(38); ?> ...<span class="full_post">সম্পূর্ণ পড়ুন</span></p>

										</div></a>
									<?php endwhile;?>
									
								</div>
							</div>
							<div class="recent col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<div class="row">
									<div class="post_heading col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<h1>বিশেষ</h1>
									</div>
								</div>
								<div class=" posts">
								
								
								<?php 
								$special = new WP_Query(array(
									'post_type'=> 'post',
									'posts_per_page'=> 4,
									'category_name'=> 'Special',
								));
								while($special->have_posts()) : $special->the_post();
								?>
								
									<a href="<?php the_permalink(); ?>">
										<div class="post_content fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<figure><?php the_post_thumbnail();?></figure>
											<h2><?php the_title(); ?> </h2>
											<h4><?php the_time(' d F Y '); ?>  | <?php the_time(' g:i a '); ?> </h4>
											<h5><?php the_field('author'); ?></h5>
											<p><?php read_more(30); ?> ...<span class="full_post">সম্পূর্ণ পড়ুন</span></p>

										</div>
									</a>
									<?php endwhile;?>
									
								</div>
							</div>
						</div>
						<div class="row  ">
							<div class="content_add col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="row ">
									<div class="c_add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="<?php global $Lokshan; echo $Lokshan['change_home_content_add_one']['url'];?>"/></center>
									</div>
								</div>
							</div>
						</div>
						<div class="row ">
							<div class="libaration_war home_post col-lg-8 col-md-8 col-sm-12 col-xs-12">
								<div class="row ">
									<div class="post_heading col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<h1>বাংলাদেশ মুক্তিযুদ্ধ</h1>
									</div>
								</div>
								<div class=" ">
								
								
								<?php 
								$freedomfighter = new WP_Query(array(
									'post_type'=> 'post',
									'posts_per_page'=> 4,
									'category_name'=> 'Freedom Fighter',
								));
								while($freedomfighter->have_posts()) : $freedomfighter->the_post();
								?>								
									<a href="<?php the_permalink(); ?>">
										<div class="post_content fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<figure><?php the_post_thumbnail();?></figure>
											<h2><?php the_title(); ?> </h2>
											<h4><?php the_time(' d F Y '); ?>  | <?php the_time(' g:i a '); ?> </h4>
											<h5><?php the_field('author'); ?></h5>
											<p><?php read_more(70); ?> ...<span class="full_post">সম্পূর্ণ পড়ুন</span></p>

										</div>
									</a>
									
								<?php endwhile;?>
								</div>
							</div>
							<div class="old_news col-lg-4 col-md-4 col-sm-12 col-xs-12">
								<div class="row ">
									<div class="post_heading col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<h1>সর্বাধিক পঠিত</h1>
									</div>
								</div>
								<div class=" ">
								<?php dynamic_sidebar('font_widget'); ?>
								
								
								
									<!--<a href="<?php the_permalink(); ?>">
										<div class="post_content fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<h2>পরীক্ষামূলক পোস্টের শিরোনাম </h2>
											<h4>ফেব্রুয়ারী ২১, ২০১৭ | ১২:৩০ অপরাহ্ন </h4>
											<p ‍>এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য  ...<span class="full_post">সম্পূর্ণ পড়ুন</span></p>

										</div>
									</a>-->
								</div>
							</div>
						</div>
						<div class="row ">
							<div class="content_add col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="row ">
									<div class="c_add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="<?php echo $Lokshan['change_home_content_add_two']['url'];?>"/></center>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="entartainment col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<div class="row">
									<div class="post_heading col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center>
											<h1>বিনোদন</h1>
										</center>
									</div>
								</div>
								<div class=" home_post">
								<div class="sub_title">
									<h4>মিডিয়া</h4>
								</div>							
								
								<?php 
								$media = new WP_Query(array(
									'post_type'=> 'post',
									'posts_per_page'=> 3,
									'category_name'=> 'Media',
								));
								while($media->have_posts()) : $media->the_post();
								?>
								
									<a href="<?php the_permalink(); ?>">
										<div class="post_content col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<figure><?php the_post_thumbnail();?></figure>
											<h2><?php the_title(); ?> </h2>
											<h4><?php the_time(' d F Y '); ?>  | <?php the_time(' g:i a '); ?> </h4>
											<h5><?php the_field('author'); ?></h5>
											<p><?php read_more(30); ?> ...<span class="full_post">সম্পূর্ণ পড়ুন</span></p>

										</div>
									</a>
									
								<?php endwhile;?>
								
								<div class="sub_title">
									<h4>চলচ্চিত্র</h4>
								</div>	
								
								<?php 
								$film = new WP_Query(array(
									'post_type'=> 'post',
									'posts_per_page'=> 2,
									'category_name'=> 'Film',
								));
								while($film->have_posts()) : $film->the_post();
								?>
								
									<a href="<?php the_permalink(); ?>">
										<div class="post_content fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<figure><?php the_post_thumbnail();?></figure>
											<h2><?php the_title(); ?> </h2>
											<h4><?php the_time(' d F Y '); ?>  | <?php the_time(' g:i a '); ?> </h4>
											<h5><?php the_field('author'); ?></h5>
											<p><?php read_more(30); ?> ...<span class="full_post">সম্পূর্ণ পড়ুন</span></p>

										</div>
									</a>
									
								<?php endwhile;?>
								
								<div class="sub_title">
									<h4>সাক্ষাৎকার</h4>
								</div>	
								
								<?php 
								$interview = new WP_Query(array(
									'post_type'=> 'post',
									'posts_per_page'=> 2,
									'category_name'=> 'Interview',
								));
								while($interview->have_posts()) : $interview->the_post();
								?>
								
									<a href="<?php the_permalink(); ?>">
										<div class="post_content fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<figure><?php the_post_thumbnail();?></figure>
											<h2><?php the_title(); ?> </h2>
											<h4><?php the_time(' d F Y '); ?>  | <?php the_time(' g:i a '); ?> </h4>
											<h5><?php the_field('author'); ?></h5>
											<p><?php read_more(30); ?> ...<span class="full_post">সম্পূর্ণ পড়ুন</span></p>

										</div>
									</a>
									
								<?php endwhile;?>
								</div>
							</div>
							<div class="story col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<div class="row fix">
									<div class="post_heading col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<h1>গল্প</h1>
									</div>
								</div>
								<div class=" ">
								
								
								
								<div class="sub_title">
									<h4>ছোট গল্প</h4>
								</div>	
								<?php 
								$shortstory = new WP_Query(array(
									'post_type'=> 'post',
									'posts_per_page'=> 2,
									'category_name'=> 'Short Story',
								));
								while($shortstory->have_posts()) : $shortstory->the_post();
								?>
								
									<a href="<?php the_permalink(); ?>">
										<div class="post_content fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<figure><?php the_post_thumbnail();?></figure>
											<h2><?php the_title(); ?> </h2>
											<h4><?php the_time(' d F Y '); ?>  | <?php the_time(' g:i a '); ?> </h4>
											<h5><?php the_field('author'); ?></h5>
											<p><?php read_more(30); ?> ...<span class="full_post">সম্পূর্ণ পড়ুন</span></p>

										</div>
									</a>
									
								<?php endwhile;?>
								
								<div class="sub_title">
									<h4>অনুগল্প</h4>
								</div>	
								
								<?php 
								$ministory = new WP_Query(array(
									'post_type'=> 'post',
									'posts_per_page'=> 3,
									'category_name'=> 'Mini Story',
								));
								while($ministory->have_posts()) : $ministory->the_post();
								?>
								
									<a href="<?php the_permalink(); ?>">
										<div class="post_content fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<figure><?php the_post_thumbnail();?></figure>
											<h2><?php the_title(); ?> </h2>
											<h4><?php the_time(' d F Y '); ?>  | <?php the_time(' g:i a '); ?> </h4>
											<h5><?php the_field('author'); ?></h5>
											<p><?php read_more(30); ?> ...<span class="full_post">সম্পূর্ণ পড়ুন</span></p>

										</div>
									</a>
									
								<?php endwhile;?>
								
								<div class="sub_title">
									<h4>অনুবাদ গল্প</h4>
								</div>	
								
								<?php 
								$translatestory = new WP_Query(array(
									'post_type'=> 'post',
									'posts_per_page'=> 2,
									'category_name'=> 'Translate Story',
								));
								while($translatestory->have_posts()) : $translatestory->the_post();
								?>
								
									<a href="<?php the_permalink(); ?>">
										<div class="post_content fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<figure><?php the_post_thumbnail();?></figure>
											<h2><?php the_title(); ?> </h2>
											<h4><?php the_time(' d F Y '); ?>  | <?php the_time(' g:i a '); ?> </h4>
											<h5><?php the_field('author'); ?></h5>
											<p><?php read_more(30); ?> ...<span class="full_post">সম্পূর্ণ পড়ুন</span></p>

										</div>
									</a>
									
								<?php endwhile;?>
								</div>
							</div>
						</div>
						<div class="row fix ">
							<div class="content_add col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="row">
									<div class="c_add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="<?php echo $Lokshan['change_home_content_add_three']['url'];?>"/></center>
									</div>
								</div>
							</div>
						</div>
						<!--
						<div class="row">
							<div class="art col-lg-4 col-md-4 col-sm-12 col-xs-12">
							ffffffffffff
							</div>
							<div class="gallery col-lg-8 col-md-8 col-sm-12 col-xs-12">
								<div class="">
								</div>
							</div>
						</div>
						-->
					</div>
					<div class="right_addcol-lg-4 col-md-4 col-sm-12 col-xs-12">
								<center>
								<div class="row fiture">
									<div class="side_heading col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center>
											<a href="#"><h1>ফিচার</h1></a>
										</center>
									</div>
									
									
					<?php 
					 	$fiture  = new WP_Query(array(
					 			'post_type'=> 'fiture',
					 			'posts_per_page' => 1
					 		));
					 ?>
					 <?php while($fiture->have_posts()) : $fiture->the_post();  ?>
										
									<div class="side_content col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center>
											<figure>
											<?php the_post_thumbnail(); ?>
												<figcaption><?php the_field('caption'); ?> <br/><span>ছবিঃ <?php the_field('photographer'); ?></span>
												</figcaption>
											</figure>

										</center>
										<div class="fiture_content">

											<p> <?php  the_content();; ?> <!--...<a href="<?php the_permalink();?>"><span class="full_post">সম্পূর্ণ পড়ুন</span></a>--></p>
											<h4 style="text-align:right;font-size:13px;font-weight:bold;color:#001B33;"> <?php the_field('fiture_author'); ?></h4>
										</div>
									</div>
									
								<?php endwhile; ?>	
									
								</div>
								</center>
								<div class="row">
									<div class="add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="<?php echo $Lokshan['change_home_right_sidebar_add_one']['url'];?>"/></center>
									</div>
								</div>
								<div class="row ">
									<div class="add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="<?php echo $Lokshan['change_home_right_sidebar_add_two']['url'];?>"/></center>
									</div>
								</div>
								<div class="row">
									<div class="add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="<?php echo $Lokshan['change_home_right_sidebar_add_three']['url'];?>"/></center>
									</div>
								</div>
								<div class="row">
									<div class="add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="<?php echo $Lokshan['change_home_right_sidebar_add_four']['url'];?>"/></center>
									</div>
								</div>
					</div>
				</div>
<?php 
get_footer();
?>