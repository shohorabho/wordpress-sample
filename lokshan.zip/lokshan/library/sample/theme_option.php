<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }


    // This is your option name where all the Redux data is stored.
    $opt_name = "Lokshan";

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'redux_demo/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

    $sampleHTML = '';
    if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
        Redux_Functions::initWpFilesystem();

        global $wp_filesystem;

        $sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
    }

    // Background Patterns Reader
    $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
    $sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
    $sample_patterns      = array();
    
    if ( is_dir( $sample_patterns_path ) ) {

        if ( $sample_patterns_dir = opendir( $sample_patterns_path ) ) {
            $sample_patterns = array();

            while ( ( $sample_patterns_file = readdir( $sample_patterns_dir ) ) !== false ) {

                if ( stristr( $sample_patterns_file, '.png' ) !== false || stristr( $sample_patterns_file, '.jpg' ) !== false ) {
                    $name              = explode( '.', $sample_patterns_file );
                    $name              = str_replace( '.' . end( $name ), '', $sample_patterns_file );
                    $sample_patterns[] = array(
                        'alt' => $name,
                        'img' => $sample_patterns_url . $sample_patterns_file
                    );
                }
            }
        }
    }

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => __( 'Lokshan Option', 'redux-framework-demo' ),
        'page_title'           => __( 'LOkshan Setting', 'redux-framework-demo' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => false,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => false,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => 3,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => 'dashicons-admin-settings',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    // ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
    $args['admin_bar_links'][] = array(
        'id'    => 'redux-docs',
        'href'  => 'http://docs.reduxframework.com/',
        'title' => __( 'Documentation', 'redux-framework-demo' ),
    );

    $args['admin_bar_links'][] = array(
        //'id'    => 'redux-support',
        'href'  => 'https://github.com/ReduxFramework/redux-framework/issues',
        'title' => __( 'Support', 'redux-framework-demo' ),
    );

    $args['admin_bar_links'][] = array(
        'id'    => 'redux-extensions',
        'href'  => 'reduxframework.com/extensions',
        'title' => __( 'Extensions', 'redux-framework-demo' ),
    );

    // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
    $args['share_icons'][] = array(
        'url'   => 'https://www.facebook.com/shohorabho',
        'title' => 'Like us on Facebook',
        'icon'  => 'el el-facebook'
    );
    $args['share_icons'][] = array(
        'url'   => 'https://twitter.com/shohorabho',
        'title' => 'Follow us on Twitter',
        'icon'  => 'el el-twitter'
    );
    $args['share_icons'][] = array(
        'url'   => 'https://www.linkedin.com/in/shohorab1993',
        'title' => 'Find us on LinkedIn',
        'icon'  => 'el el-linkedin'
    );

    // Panel Intro text -> before the form
    if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
        if ( ! empty( $args['global_variable'] ) ) {
            $v = $args['global_variable'];
        } else {
            $v = str_replace( '-', '_', $args['opt_name'] );
        }
        $args['intro_text'] = sprintf( __( '', 'redux-framework-demo' ), $v );
    } else {
        $args['intro_text'] = __( '<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'redux-framework-demo' );
    }

    // Add content after the form.
    $args['footer_text'] = __( '', 'redux-framework-demo' );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */


    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'redux-framework-demo' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'redux-framework-demo' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'redux-framework-demo' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */

    /*

        As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


     */
	 
	 
	 
	 
	 //Start My Section 
	 
	 // Start Header Option 
	 
	 Redux::setSection($opt_name,array(
			'title'    =>  __('Header Option','lokshan'),
			'id'       =>  'header_option',
			'desc'	   => __('All filed of header area','lokshan'),
			'icon'	   => 'el el-braille',
	 ) );
	 
	 Redux::setSection( $opt_name, array(
			'title' 		  => __('Header Logo','lokshan'),
			'id'     		  => 'header_option_logo',
			'subsection'      => true,
			'desc'            => __( 'Change logo on your website ', 'lokshan' ) ,
			'fields'          => array(
            array(
                'id'       => 'logo_change',
                'type'     => 'media',
                'title'    => __( 'Change Logo', 'lokshan' ),
                'subtitle' => __( 'Upload logo file on this area', 'lokshan' ),
                'desc'     => __( 'You should upload a valid image file', 'lokshan' ),
                'default'  => array( 
						'url' => get_template_directory_uri().'/images/lg.png'),
				),
            ),
	 )  );
	 
	 Redux::setSection( $opt_name, array(
			'title' 		  => __('Header Title','lokshan'),
			'id'     		  => 'header_title',
			'subsection'      => true,
			'fields'          => array(
            array(
                'id'       => 'edit_title',
                'type'     => 'opt_editor',
                'title'    => __( 'Title edit', 'lokshan' ),
                'subtitle' => __( 'Type your title on this area', 'lokshan' ),
                'desc'     => __( 'You may use html too on this area', 'lokshan' ),
				),
            array(
                'id'       => 'fitst_text_change',
                'type'     => 'text',
                'title'    => __( 'Change your header 1st text', 'lokshan' ),
                'desc'     => __( 'Use one letter for one field', 'lokshan' ),
				'default'  => 'লো',
				),
            array(
                'id'       => 'second_text_change',
                'type'     => 'text',
                'title'    => __( 'Change your header 2nd text', 'lokshan' ),
                'desc'     => __( 'Use one letter for one field', 'lokshan' ),
				'default'  => 'ক',
				),
            array(
                'id'       => 'third_text_change',
                'type'     => 'text',
                'title'    => __( 'Change your header 3rd text', 'lokshan' ),
                'desc'     => __( 'Use one letter for one field', 'lokshan' ),
				'default'  => 'শা',
				),
            array(
                'id'       => 'fourth_text_change',
                'type'     => 'text',
                'title'    => __( 'Change your header 4th text', 'lokshan' ),
                'desc'     => __( 'Use one letter for one field', 'lokshan' ),
				'default'  => 'ন',
				),
            array(
                'id'       => 'fifth_text_change',
                'type'     => 'text',
                'title'    => __( 'Change your header 5th text', 'lokshan' ),
                'desc'     => __( 'Use one letter for one field', 'lokshan' ),
				),
            array(
                'id'       => 'sixth_text_change',
                'type'     => 'text',
                'title'    => __( 'Change your header 6th text', 'lokshan' ),
                'desc'     => __( 'Use one letter for one field', 'lokshan' ),
				),
            array(
                'id'       => 'seventh_text_change',
                'type'     => 'text',
                'title'    => __( 'Change your header 7th text', 'lokshan' ),
                'desc'     => __( 'Use one letter for one field', 'lokshan' ),
				),
            array(
                'id'       => 'eighth_text_change',
                'type'     => 'text',
                'title'    => __( 'Change your header 8th text', 'lokshan' ),
                'desc'     => __( 'Use one letter for one field', 'lokshan' ),
				),
            array(
                'id'       => 'title_link_change',
                'type'     => 'text',
                'title'    => __( 'Change Sub Title', 'lokshan' ),
                'desc'     => __( 'This field is for change text and link of sub title under website title', 'lokshan' ),
				'default'  => 'www.lokshan.com'
				),
            ),
	 )  );
	 
	 Redux::setSection( $opt_name, array(
			'title' 		  => __('Header Contact','lokshan'),
			'id'     		  => 'header_contact',
			'subsection'      => true,
			'fields'          => array(
            array(
                'id'       => 'edit_Contact',
                'type'     => 'editor',
                'title'    => __( 'Contact Information', 'lokshan' ),
                'subtitle' => __( 'Edit your contact information on this area', 'lokshan' ),
                'desc'     => __( 'You may use html too on this area', 'lokshan' ),
				),
            array(
                'id'       => 'add_social_link',
                'type'     => 'opt_editor',
                'title'    => __( 'Add social link', 'lokshan' ),
                'subtitle' => __( 'Enter full url of your social link', 'lokshan' ),
                'desc'     => __( 'e.g. wwww.facebook.com/shohorabho', 'lokshan' ),
				),
            ),
	 )  );
	 
	 
	 // Start All ADD Option 
	 
	 Redux::setSection($opt_name,array(
			'title'    =>  __('All ADD Setting','lokshan'),
			'id'       =>  'all_add_option',
			'desc'	   => __('Setting of all ADD','lokshan'),
			'icon'	   => 'el el-time',
	 ) );
	 
	 //set header ADD section
	 Redux::setSection( $opt_name, array(
			'title' 		  => __('Set Header ADD','lokshan'),
			'id'     		  => 'header_add_option',
			'subsection'      => true,
			'desc'            => __( 'Header ADD section . Set your header ADD ', 'lokshan' ) ,
			'fields'          => array(
            array(
                'id'       => 'change_header_add',
                'type'     => 'media',
                'title'    => __( 'Change header ADD here', 'lokshan' ),
                'subtitle' => __( 'It should be 500*100', 'lokshan' ),
                'desc'     => __( 'This is for only header .', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add-500.100.2.png'),
				),
            ),
	 )  );
	 
	 //set home page ADD section
	 Redux::setSection( $opt_name, array(
			'title' 		  => __('Set Home Page ADD','lokshan'),
			'id'     		  => 'home_page_add_option',
			'subsection'      => true,
			'desc'            => __( 'This is for only Home Page section . Set all home page ADD ', 'lokshan' ) ,
			'fields'          => array(
			//Set 500*100 ADD
            array(
                'id'       => 'change_home_content_add_one',
                'type'     => 'media',
                'title'    => __( 'Change Home content ADD one', 'lokshan' ),
                'subtitle' => __( 'It should be 500*100', 'lokshan' ),
                'desc'     => __( 'This is first home content add .', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add-500.100.2.png'),
				),
            array(
                'id'       => 'change_home_content_add_two',
                'type'     => 'media',
                'title'    => __( 'Change Home content ADD two', 'lokshan' ),
                'subtitle' => __( 'It should be 500*100', 'lokshan' ),
                'desc'     => __( 'This is second home content add .', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add-500.100.2.png'),
				),
            array(
                'id'       => 'change_home_content_add_three',
                'type'     => 'media',
                'title'    => __( 'Change Home content ADD three', 'lokshan' ),
                'subtitle' => __( 'It should be 500*100', 'lokshan' ),
                'desc'     => __( 'This is third home content add .', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add-500.100.2.png'),
				),
				//set 300*100 ADD
            array(
                'id'       => 'change_home_right_sidebar_add_one',
                'type'     => 'media',
                'title'    => __( 'Change Home Right Sidebar ADD one', 'lokshan' ),
                'subtitle' => __( 'It should be 300*100', 'lokshan' ),
                'desc'     => __( 'This is first home right sidebar ADD .', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add.png'),
				),
            array(
                'id'       => 'change_home_right_sidebar_add_two',
                'type'     => 'media',
                'title'    => __( 'Change Home Right Sidebar ADD two', 'lokshan' ),
                'subtitle' => __( 'It should be 300*100', 'lokshan' ),
                'desc'     => __( 'This is second home right sidebar ADD .', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add.png'),
				),
            array(
                'id'       => 'change_home_right_sidebar_add_three',
                'type'     => 'media',
                'title'    => __( 'Change Home Right Sidebar ADD three', 'lokshan' ),
                'subtitle' => __( 'It should be 300*100', 'lokshan' ),
                'desc'     => __( 'This is third home right sidebar ADD .', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add.png'),
				),
            array(
                'id'       => 'change_home_right_sidebar_add_four',
                'type'     => 'media',
                'title'    => __( 'Change Home Right Sidebar ADD four', 'lokshan' ),
                'subtitle' => __( 'It should be 300*100', 'lokshan' ),
                'desc'     => __( 'This is fourth home right sidebar ADD .', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add.png'),
				),
            ),
	 )  );
	 
	 //set page ADD section
	 Redux::setSection( $opt_name, array(
			'title' 		  => __('Set Page ADD','lokshan'),
			'id'     		  => 'page_add_option',
			'subsection'      => true,
			'desc'            => __( 'This is for all Page section . Set all page ADD  here', 'lokshan' ) ,
			'fields'          => array(
			//Set 500*100 ADD
            array(
                'id'       => 'change_page_content_add_one',
                'type'     => 'media',
                'title'    => __( 'Change Page content ADD', 'lokshan' ),
                'subtitle' => __( 'It should be 500*100', 'lokshan' ),
                'desc'     => __( 'This is only and one page content ADD .', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add-500.100.2.png'),
				),
				
				
				//set 300*100 ADD
            array(
                'id'       => 'change_page_right_sidebar_add_one',
                'type'     => 'media',
                'title'    => __( 'Change Page Right Sidebar ADD one', 'lokshan' ),
                'subtitle' => __( 'It should be 300*100', 'lokshan' ),
                'desc'     => __( 'This is first page right sidebar ADD .It will be changes all pages first ADD', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add.png'),
				),
            array(
                'id'       => 'change_page_right_sidebar_add_two',
                'type'     => 'media',
                'title'    => __( 'Change Page Right Sidebar ADD two', 'lokshan' ),
                'subtitle' => __( 'It should be 300*100', 'lokshan' ),
                'desc'     => __( 'This is second page right sidebar ADD .It will be changes all pages second ADD', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add.png'),
				),
            array(
                'id'       => 'change_page_right_sidebar_add_three',
                'type'     => 'media',
                'title'    => __( 'Change Page Right Sidebar ADD three', 'lokshan' ),
                'subtitle' => __( 'It should be 300*100', 'lokshan' ),
                'desc'     => __( 'This is third page right sidebar ADD .It will be changes all pages third ADD', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add.png'),
				),
            array(
                'id'       => 'change_page_right_sidebar_add_four',
                'type'     => 'media',
                'title'    => __( 'Change Page Right Sidebar ADD four', 'lokshan' ),
                'subtitle' => __( 'It should be 300*100', 'lokshan' ),
                'desc'     => __( 'This is fourth page right sidebar ADD .It will be changes all pages foutrh ADD', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add.png'),
				),
            ),
	 )  );
	 
	 
	 //set single page ADD section
	 Redux::setSection( $opt_name, array(
			'title' 		  => __('Set Single Page ADD','lokshan'),
			'id'     		  => 'single_page_add_option',
			'subsection'      => true,
			'desc'            => __( 'This is for all single Page section . Set all single page ADD  here', 'lokshan' ) ,
			'fields'          => array(
			//Set 500*100 ADD
            array(
                'id'       => 'change_single_page_content_add_one',
                'type'     => 'media',
                'title'    => __( 'Change Single Page content ADD', 'lokshan' ),
                'subtitle' => __( 'It should be 700*120', 'lokshan' ),
                'desc'     => __( 'This is only and one Single page content ADD .', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add-500.100.2.png'),
				),
				
				
				//set 300*100 ADD
            array(
                'id'       => 'change_single_page_right_sidebar_add_one',
                'type'     => 'media',
                'title'    => __( 'Change Single Page Right Sidebar ADD one', 'lokshan' ),
                'subtitle' => __( 'It should be 330*120', 'lokshan' ),
                'desc'     => __( 'This is first single page right sidebar ADD .It will be changes all single pages first ADD', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add.png'),
				),
            array(
                'id'       => 'change_single_page_right_sidebar_add_two',
                'type'     => 'media',
                'title'    => __( 'Change Single Page Right Sidebar ADD two', 'lokshan' ),
                'subtitle' => __( 'It should be 300*120', 'lokshan' ),
                'desc'     => __( 'This is second single page right sidebar ADD .It will be changes all single pages second ADD', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add.png'),
				),
            array(
                'id'       => 'change_single_page_right_sidebar_add_three',
                'type'     => 'media',
                'title'    => __( 'Change Single Page Right Sidebar ADD three', 'lokshan' ),
                'subtitle' => __( 'It should be 300*120', 'lokshan' ),
                'desc'     => __( 'This is third single page right sidebar ADD .It will be changes all single pages third ADD', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add.png'),
				),
            array(
                'id'       => 'change_single_page_right_sidebar_add_four',
                'type'     => 'media',
                'title'    => __( 'Change Single Page Right Sidebar ADD four', 'lokshan' ),
                'subtitle' => __( 'It should be 300*120', 'lokshan' ),
                'desc'     => __( 'This is fourth page right sidebar ADD .It will be changes all single pages fourth ADD', 'lokshan' ),
                'default'  =>array( 
						'url' => get_template_directory_uri().'/images/header-add.png'),
				),
            ),
	 )  );
	 
	 
	 
	 // Start Footer Option 
	 
	 Redux::setSection($opt_name,array(
			'title'    =>  __('Footer Option','lokshan'),
			'id'       =>  'footer_option',
			'desc'	   => __('All filed of footer area','lokshan'),
			'icon'	   => 'el el-time',
	 ) );
	 
	 Redux::setSection( $opt_name, array(
			'title' 		  => __('Copy right','lokshan'),
			'id'     		  => 'copy_right_option',
			'subsection'      => true,
			'desc'            => __( 'Copy right edit option for your footer ', 'lokshan' ) ,
			'fields'          => array(
			
            array(
                'id'       => 'copy_right_text',
                'type'     => 'editor',
                'title'    => __( 'Update Your Copy right Text', 'lokshan' ),
                'subtitle' => __( '', 'lokshan' ),
                'desc'     => __( 'Enter full copy right text', 'lokshan' ),
                'default'  => 'সর্বস্বত্ব স্বত্বাধিকার সংরক্ষিত &copy; ২০১৭',
				),
            ),
	 )  );
	 
	 Redux::setSection( $opt_name, array(
			'title' 		  => __('Footer warning','lokshan'),
			'id'     		  => 'footer_warning_option',
			'subsection'      => true,
			'desc'            => __( 'Warning edit option for your footer ', 'lokshan' ) ,
			'fields'          => array(
			
            array(
                'id'       => 'warning_text_change',
                'type'     => 'editor',
                'title'    => __( 'Change Footer warning text', 'lokshan' ),
                'subtitle' => __( '', 'lokshan' ),
                'desc'     => __( 'You can edit here of your footer warning text', 'lokshan' ),
                'default'  => ' এই ওয়েবসাইটের কোনো লেখা, ছবি অনুমতি ব্যথিত ব্যবহার বেআইনি ',
				),
            ),
	 )  );
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 

    // -> START Basic Fields
    
	
	//v
	
	/*Redux::setSection( $opt_name, array(
        'title'            => __( 'Basic Fields', 'redux-framework-demo' ),
        'id'               => 'basic',
        'desc'             => __( 'These are really basic fields!', 'redux-framework-demo' ),
        'customizer_width' => '400px',
        'icon'             => 'el el-home'
    ) );

    Redux::setSection( $opt_name, array(
        'title'            => __( 'Checkbox', 'redux-framework-demo' ),
        'id'               => 'basic-checkbox',
        'subsection'       => true,
        'customizer_width' => '450px',
        'desc'             => __( 'For full documentation on this field, visit: ', 'redux-framework-demo' ) . '<a href="//docs.reduxframework.com/core/fields/checkbox/" target="_blank">docs.reduxframework.com/core/fields/checkbox/</a>',
        'fields'           => array(
            array(
                'id'       => 'opt-checkbox',
                'type'     => 'checkbox',
                'title'    => __( 'Checkbox Option', 'redux-framework-demo' ),
                'subtitle' => __( 'No validation can be done on this field type', 'redux-framework-demo' ),
                'desc'     => __( 'This is the description field, again good for additional info.', 'redux-framework-demo' ),
                'default'  => '1'// 1 = on | 0 = off
            ),
            array(
                'id'       => 'opt-multi-check',
                'type'     => 'checkbox',
                'title'    => __( 'Multi Checkbox Option', 'redux-framework-demo' ),
                'subtitle' => __( 'No validation can be done on this field type', 'redux-framework-demo' ),
                'desc'     => __( 'This is the description field, again good for additional info.', 'redux-framework-demo' ),
                //Must provide key => value pairs for multi checkbox options
                'options'  => array(
                    '1' => 'Opt 1',
                    '2' => 'Opt 2',
                    '3' => 'Opt 3'
                ),
                //See how std has changed? you also don't need to specify opts that are 0.
                'default'  => array(
                    '1' => '1',
                    '2' => '0',
                    '3' => '0'
                )
            ),
            array(
                'id'       => 'opt-checkbox-data',
                'type'     => 'checkbox',
                'title'    => __( 'Multi Checkbox Option (with menu data)', 'redux-framework-demo' ),
                'subtitle' => __( 'No validation can be done on this field type', 'redux-framework-demo' ),
                'desc'     => __( 'This is the description field, again good for additional info.', 'redux-framework-demo' ),
                'data'     => 'menu'
            ),
            array(
                'id'       => 'opt-checkbox-sidebar',
                'type'     => 'checkbox',
                'title'    => __( 'Multi Checkbox Option (with sidebar data)', 'redux-framework-demo' ),
                'subtitle' => __( 'No validation can be done on this field type', 'redux-framework-demo' ),
                'desc'     => __( 'This is the description field, again good for additional info.', 'redux-framework-demo' ),
                'data'     => 'sidebars'
            ),
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title'            => __( 'Radio', 'redux-framework-demo' ),
        'id'               => 'basic-Radio',
        'subsection'       => true,
        'customizer_width' => '500px',
        'desc'             => __( 'For full documentation on this field, visit: ', 'redux-framework-demo' ) . '<a href="//docs.reduxframework.com/core/fields/radio/" target="_blank">docs.reduxframework.com/core/fields/radio/</a>',
        'fields'           => array(
            array(
                'id'       => 'opt-radio',
                'type'     => 'radio',
                'title'    => __( 'Radio Option', 'redux-framework-demo' ),
                'subtitle' => __( 'No validation can be done on this field type', 'redux-framework-demo' ),
                'desc'     => __( 'This is the description field, again good for additional info.', 'redux-framework-demo' ),
                //Must provide key => value pairs for radio options
                'options'  => array(
                    '1' => 'Opt 1',
                    '2' => 'Opt 2',
                    '3' => 'Opt 3'
                ),
                'default'  => '2'
            ),
            array(
                'id'       => 'opt-radio-data',
                'type'     => 'radio',
                'title'    => __( 'Radio Option w/ Menu Data', 'redux-framework-demo' ),
                'subtitle' => __( 'No validation can be done on this field type', 'redux-framework-demo' ),
                'desc'     => __( 'This is the description field, again good for additional info.', 'redux-framework-demo' ),
                'data'     => 'menu'
            ),
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Sortable', 'redux-framework-demo' ),
        'id'         => 'basic-Sortable',
        'subsection' => true,
        'desc'       => __( 'For full documentation on this field, visit: ', 'redux-framework-demo' ) . '<a href="//docs.reduxframework.com/core/fields/sortable/" target="_blank">docs.reduxframework.com/core/fields/sortable/</a>',
        'fields'     => array(
            array(
                'id'       => 'opt-sortable',
                'type'     => 'sortable',
                'title'    => __( 'Sortable Text Option', 'redux-framework-demo' ),
                'subtitle' => __( 'Define and reorder these however you want.', 'redux-framework-demo' ),
                'desc'     => __( 'This is the description field, again good for additional info.', 'redux-framework-demo' ),
                'label'    => true,
                'options'  => array(
                    'Text One'   => 'Item 1',
                    'Text Two'   => 'Item 2',
                    'Text Three' => 'Item 3',
                )
            ),
            array(
                'id'       => 'opt-check-sortable',
                'type'     => 'sortable',
                'mode'     => 'checkbox', // checkbox or text
                'title'    => __( 'Sortable Text Option', 'redux-framework-demo' ),
                'subtitle' => __( 'Define and reorder these however you want.', 'redux-framework-demo' ),
                'desc'     => __( 'This is the description field, again good for additional info.', 'redux-framework-demo' ),
                'options'  => array(
                    'cb1' => 'Checkbox One',
                    'cb2' => 'Checkbox Two',
                    'cb3' => 'Checkbox Three',
                ),
                'default'  => array(
                    'cb1' => false,
                    'cb2' => true,
                    'cb3' => false,
                )
            ),
        )
    ) );


    Redux::setSection( $opt_name, array(
        'title'            => __( 'Text', 'redux-framework-demo' ),
        'desc'             => __( 'For full documentation on this field, visit: ', 'redux-framework-demo' ) . '<a href="//docs.reduxframework.com/core/fields/text/" target="_blank">docs.reduxframework.com/core/fields/text/</a>',
        'id'               => 'basic-Text',
        'subsection'       => true,
        'customizer_width' => '700px',
        'fields'           => array(
            array(
                'id'       => 'text-example',
                'type'     => 'text',
                'title'    => __( 'Text Field', 'redux-framework-demo' ),
                'subtitle' => __( 'Subtitle', 'redux-framework-demo' ),
                'desc'     => __( 'Field Description', 'redux-framework-demo' ),
                'default'  => 'Default Text',
            ),
            array(
                'id'        => 'text-example-hint',
                'type'      => 'text',
                'title'     => __( 'Text Field w/ Hint', 'redux-framework-demo' ),
                'subtitle'  => __( 'Subtitle', 'redux-framework-demo' ),
                'desc'      => __( 'Field Description', 'redux-framework-demo' ),
                'default'   => 'Default Text',
                'text_hint' => array(
                    'title'   => 'Hint Title',
                    'content' => 'Hint content about this field!'
                )
            ),
            array(
                'id'          => 'text-placeholder',
                'type'        => 'text',
                'title'       => __( 'Text Field', 'redux-framework-demo' ),
                'subtitle'    => __( 'Subtitle', 'redux-framework-demo' ),
                'desc'        => __( 'Field Description', 'redux-framework-demo' ),
                'placeholder' => 'Placeholder Text',
            ),

        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Multi Text', 'redux-framework-demo' ),
        'id'         => 'basic-Multi Text',
        'desc'       => __( 'For full documentation on this field, visit: ', 'redux-framework-demo' ) . '<a href="//docs.reduxframework.com/core/fields/multi-text/" target="_blank">docs.reduxframework.com/core/fields/multi-text/</a>',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'opt-multitext',
                'type'     => 'multi_text',
                'title'    => __( 'Multi Text Option', 'redux-framework-demo' ),
                'subtitle' => __( 'Field subtitle', 'redux-framework-demo' ),
                'desc'     => __( 'Field Decription', 'redux-framework-demo' ),
            ),
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Password', 'redux-framework-demo' ),
        'id'         => 'basic-Password',
        'desc'       => __( 'For full documentation on this field, visit: ', 'redux-framework-demo' ) . '<a href="//docs.reduxframework.com/core/fields/password/" target="_blank">docs.reduxframework.com/core/fields/password/</a>',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'password',
                'type'     => 'password',
                'username' => true,
                'title'    => 'Password Field',
                //'placeholder' => array(
                //    'username' => 'Username',
                //    'password' => 'Password',
                //)
            )
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Textarea', 'redux-framework-demo' ),
        'id'         => 'basic-Textarea',
        'desc'       => __( 'For full documentation on this field, visit: ', 'redux-framework-demo' ) . '<a href="//docs.reduxframework.com/core/fields/textarea/" target="_blank">docs.reduxframework.com/core/fields/textarea/</a>',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'opt-textarea',
                'type'     => 'textarea',
                'title'    => __( 'Textarea Option - HTML Validated Custom', 'redux-framework-demo' ),
                'subtitle' => __( 'Subtitle', 'redux-framework-demo' ),
                'desc'     => __( 'This is the description field, again good for additional info.', 'redux-framework-demo' ),
                'default'  => 'Default Text',
            )
        )
    ) );






    Redux::setSection( $opt_name, array(
        'id'   => 'presentation-divide-sample',
        'type' => 'divide',
    ) );

	
	
	
	
	
	
	
    // -> START Required
   
   
   //v
    /*Redux::setSection( $opt_name, array(
        'title'      => __( 'Field Required / Linking', 'redux-framework-demo' ),
        'id'         => 'required',
        'desc'       => __( '', 'redux-framework-demo' ) . '',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'opt-required-basic',
                'type'     => 'switch',
                'title'    => 'Basic Required Example',
                'subtitle' => 'Click <code>On</code> to see the text field appear.',
                'default'  => false
            ),
            array(
                'id'       => 'opt-required-basic-text',
                'type'     => 'text',
                'title'    => 'Basic Text Field',
                'subtitle' => 'This text field is only show when the above switch is set to <code>On</code>, using the <code>required</code> argument.',
                'required' => array( 'opt-required-basic', '=', true )
            ),
            array(
                'id'   => 'opt-required-divide-1',
                'type' => 'divide'
            ),
            array(
                'id'       => 'opt-required-nested',
                'type'     => 'switch',
                'title'    => 'Nested Required Example',
                'subtitle' => 'Click <code>On</code> to see another set of options appear.',
                'default'  => false
            ),
            array(
                'id'       => 'opt-required-nested-buttonset',
                'type'     => 'button_set',
                'title'    => 'Multiple Nested Required Examples',
                'subtitle' => 'Click any buton to show different fields based on their <code>required</code> statements.',
                'options'  => array(
                    'button-text'     => 'Show Text Field',
                    'button-textarea' => 'Show Textarea Field',
                    'button-editor'   => 'Show WP Editor',
                    'button-ace'      => 'Show ACE Editor'
                ),
                'required' => array( 'opt-required-nested', '=', true ),
                'default'  => 'button-text'
            ),
            array(
                'id'       => 'opt-required-nested-text',
                'type'     => 'text',
                'title'    => 'Nested Text Field',
                'required' => array( 'opt-required-nested-buttonset', '=', 'button-text' )
            ),
            array(
                'id'       => 'opt-required-nested-textarea',
                'type'     => 'textarea',
                'title'    => 'Nested Textarea Field',
                'required' => array( 'opt-required-nested-buttonset', '=', 'button-textarea' )
            ),
            array(
                'id'       => 'opt-required-nested-editor',
                'type'     => 'editor',
                'title'    => 'Nested Editor Field',
                'required' => array( 'opt-required-nested-buttonset', '=', 'button-editor' )
            ),
            array(
                'id'       => 'opt-required-nested-ace',
                'type'     => 'ace_editor',
                'title'    => 'Nested ACE Editor Field',
                'required' => array( 'opt-required-nested-buttonset', '=', 'button-ace' )
            ),
            array(
                'id'   => 'opt-required-divide-2',
                'type' => 'divide'
            ),
            array(
                'id'       => 'opt-required-select',
                'type'     => 'select',
                'title'    => 'Select Required Example',
                'subtitle' => 'Select a different option to display its value.  Required may be used to display multiple & reusable fields',
                'options'  => array(
                    'no-sidebar'    => 'No Sidebars',
                    'left-sidebar'  => 'Left Sidebar',
                    'right-sidebar' => 'Right Sidebar',
                    'both-sidebars' => 'Both Sidebars'
                ),
                'default'  => 'no-sidebar',
                'select2'  => array( 'allowClear' => false )
            ),
            array(
                'id'       => 'opt-required-select-left-sidebar',
                'type'     => 'select',
                'title'    => 'Select Left Sidebar',
                'data'     => 'sidebars',
                'default'  => '',
                'required' => array( 'opt-required-select', '=', array( 'left-sidebar', 'both-sidebars' ) )
            ),
            array(
                'id'       => 'opt-required-select-right-sidebar',
                'type'     => 'select',
                'title'    => 'Select Right Sidebar',
                'data'     => 'sidebars',
                'default'  => '',
                'required' => array( 'opt-required-select', '=', array( 'right-sidebar', 'both-sidebars' ) )
            ),
        )
    ) );


    Redux::setSection( $opt_name, array(
        'icon'            => 'el el-list-alt',
        'title'           => __( 'Customizer Only', 'redux-framework-demo' ),
        'desc'            => __( '<p class="description">This Section should be visible only in Customizer</p>', 'redux-framework-demo' ),
        'customizer_only' => true,
        'fields'          => array(
            array(
                'id'              => 'opt-customizer-only',
                'type'            => 'select',
                'title'           => __( 'Customizer Only Option', 'redux-framework-demo' ),
                'subtitle'        => __( 'The subtitle is NOT visible in customizer', 'redux-framework-demo' ),
                'desc'            => __( 'The field desc is NOT visible in customizer.', 'redux-framework-demo' ),
                'customizer_only' => true,
                //Must provide key => value pairs for select options
                'options'         => array(
                    '1' => 'Opt 1',
                    '2' => 'Opt 2',
                    '3' => 'Opt 3'
                ),
                'default'         => '2'
            ),
        )
    ) ); 
	
	//c

	
	
	
	//v
    /*if ( file_exists( dirname( __FILE__ ) . '/../README.md' ) ) {
        $section = array(
            'icon'   => 'el el-list-alt',
            'title'  => __( 'Documentation', 'redux-framework-demo' ),
            'fields' => array(
                array(
                    'id'       => '17',
                    'type'     => 'raw',
                    'markdown' => true,
                    'content_path' => dirname( __FILE__ ) . '/../README.md', // FULL PATH, not relative please
                    //'content' => 'Raw content here',
                ),
            ),
        );
        Redux::setSection( $opt_name, $section );
    }*/
	
	//c
	
	
    /*
     * <--- END SECTIONS
     */


    /*
     *
     * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
     *
     */

    /*
    *
    * --> Action hook examples
    *
    */

    // If Redux is running as a plugin, this will remove the demo notice and links
    //add_action( 'redux/loaded', 'remove_demo' );

    // Function to test the compiler hook and demo CSS output.
    // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
    //add_filter('redux/options/' . $opt_name . '/compiler', 'compiler_action', 10, 3);

    // Change the arguments after they've been declared, but before the panel is created
    //add_filter('redux/options/' . $opt_name . '/args', 'change_arguments' );

    // Change the default value of a field after it's been set, but before it's been useds
    //add_filter('redux/options/' . $opt_name . '/defaults', 'change_defaults' );

    // Dynamically add a section. Can be also used to modify sections/fields
    //add_filter('redux/options/' . $opt_name . '/sections', 'dynamic_section');

    /**
     * This is a test function that will let you see when the compiler hook occurs.
     * It only runs if a field    set with compiler=>true is changed.
     * */
    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $field['msg']    = 'your custom error message';
                $return['error'] = $field;
            }

            if ( $warning == false ) {
                $field['msg']      = 'your custom warning message';
                $return['warning'] = $field;
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => __( 'Section via hook', 'redux-framework-demo' ),
                'desc'   => __( '', 'redux-framework-demo' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }
    }

    /**
     * Removes the demo link and the notice of integrated demo from the redux-framework plugin
     */
    if ( ! function_exists( 'remove_demo' ) ) {
        function remove_demo() {
            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                remove_filter( 'plugin_row_meta', array(
                    ReduxFrameworkPlugin::instance(),
                    'plugin_metalinks'
                ), null, 2 );

                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
            }
        }
    }

