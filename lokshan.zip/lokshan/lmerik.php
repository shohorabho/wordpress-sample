<?php 
/*
Template Name:Limeric
*/

get_header();

?>
				

				<div class="row content_row">
					<div class="content fix col-lg-8 col-md-8 col-sm-8 col-xs-12">
						<center>
							<div style="width: 100%;" class="row fix" ‍>
								<div class="post_heading col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
									<center>
										<h1>লিমেরিক</h1>
									</center>
								</div>
							</div>
						</center>
						<div class="row width_ninty_eight fix">
							<div class="update col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="row home_post fix">
								
								<?php 
								$limeric = new WP_Query(array(
									'post_type'=> 'post',
									'category_name'=> 'Limeric',
									'pagination'=>true,
								));
								while($limeric->have_posts()) : $limeric->the_post();
								?>
								
								
										<div class="s_post_content fix col-lg-6 col-md-6 col-sm-6 col-xs-12">
											<center>
												<figure><?php the_post_thumbnail();?>
														<figcaption><span class="s_post_photo">ছবিঃ <?php the_field('photo_source'); ?></span>
														</figcaption>
												</figure>
											</center>
											<a href="<?php the_permalink(); ?>"><h2><?php the_title();?> </h2></a>
											<h4><?php the_time(' d F Y '); ?>  | <?php the_time(' g:i a '); ?> </h4>
											<h5><?php the_field('author'); ?></h5>
											<p><?php read_more(60); ?>  ...<a href="<?php the_permalink(); ?>"><span class="full_post">সম্পূর্ণ পড়ুন</span></a></p>
										</div>
									<?php endwhile; ?>
										
										<center>
											<div class="row pagination fix" style="width:100%;min-height: 30px; margin-top: 10px;margin-bottom:">
													
										<?php the_posts_pagination( array(
			   									 'mid_size' => 2,
			    								 'prev_text' => __( 'পূর্ববর্তী', 'lokashan' ),
			   									 'next_text' => __( 'পরবর্তী', 'lokashan' ),
			   									 'screen_reader_text' => __( ' ', 'lokashan' ),
												) ); 

										?>
											</div>
										</center>
								</div>
							</div>
						</div>
						<div class="row fix ">
							<div class="content_add col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="row fix">
									<div class="c_add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="<?php global $Lokshan; echo $Lokshan['change_page_content_add_one']['url'];?>"/></center>
									</div>
								</div>
							</div>
						</div>
						<!--
						<div class="row fix">
							<div class="art col-lg-4 col-md-4 col-sm-4 col-xs-12">
							ffffffffffff
							</div>
							<div class="gallery col-lg-8 col-md-8 col-sm-8 col-xs-12">
								<div class="">
								</div>
							</div>
						</div>
						-->
					</div>
					<div class="right_add fix col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<center>
									<div class="row fiture fix">
									<?php dynamic_sidebar('right_sidebar_widget'); ?>
			
									</div>
								</center>
								<div class="row fix">
									<div class="add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="<?php echo $Lokshan['change_page_right_sidebar_add_one']['url'];?>"/></center>
									</div>
								</div>
								<div class="row fix">
									<div class="add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="<?php echo $Lokshan['change_page_right_sidebar_add_two']['url'];?>"/></center>
									</div>
								</div>
								<div class="row fix">
									<div class="add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="<?php echo $Lokshan['change_page_right_sidebar_add_three']['url'];?>"/></center>
									</div>
								</div>
								<div class="row fix">
									<div class="add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="<?php echo $Lokshan['change_page_right_sidebar_add_four']['url'];?>"/></center>
									</div>
								</div>
					</div>
				</div>
				
<?php

get_footer();
?>


