<?php 


get_header();

?>
				

				<div class="row content_row fix">
					<div class="content fix col-lg-8 col-md-8 col-sm-8 col-xs-12">
						<center>
							<div style="width: 100%;" class="row fix" ‍>
								<div class="post_heading col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
									<center>
										<h1>পেইজের শিরোনাম</h1>
									</center>
								</div>
							</div>
						</center>
						<div class="row width_ninty_eight fix">
							<div class="update col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="row home_post fix">
										<div class="s_post_content fix col-lg-6 col-md-6 col-sm-6 col-xs-12">
											<center>
												<figure><img src="images/tree.png" alt="News Image"/>
														<figcaption><span class="s_post_photo">ছবিঃ পটোগ্রাফারের নাম</span>
														</figcaption>
												</figure>
											</center>
											<a href="single-page.html"><h2>পরীক্ষামূলক পোস্টের শিরোনাম </h2></a>
											<h4>ফেব্রুয়ারী ২১, ২০১৭ | ১২:৩০ অপরাহ্ন </h4>
											<h5>ষ্টাফ রিপোর্টার</h5>
											<p>এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য  এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য পরীক্ষা মূলক ভাবে দেখার জন্য  ...<a href="single-page.html"><span class="full_post">সম্পূর্ণ পড়ুন</span></a></p>
										</div>
										<div class="s_post_content fix col-lg-6 col-md-6 col-sm-6 col-xs-12">
											<center>
												<figure><img src="images/tree.png" alt="News Image"/>
														<figcaption><span class="s_post_photo">ছবিঃ পটোগ্রাফারের নাম</span>
														</figcaption>
												</figure>
											</center>
											<a href="single-page.html"><h2>পরীক্ষামূলক পোস্টের শিরোনাম </h2></a>
											<h4>ফেব্রুয়ারী ২১, ২০১৭ | ১২:৩০ অপরাহ্ন </h4>
											<h5>ষ্টাফ রিপোর্টার</h5>
											<p>এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য  এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য পরীক্ষা মূলক ভাবে দেখার জন্য  ...<a href="single-page.html"><span class="full_post">সম্পূর্ণ পড়ুন</span></a></p>
										</div>
										<div class="s_post_content fix col-lg-6 col-md-6 col-sm-6 col-xs-12">
											<center>
												<figure><img src="images/tree.png" alt="News Image"/>
														<figcaption><span class="s_post_photo">ছবিঃ পটোগ্রাফারের নাম</span>
														</figcaption>
												</figure>
											</center>
											<a href="single-page.html"><h2>পরীক্ষামূলক পোস্টের শিরোনাম </h2></a>
											<h4>ফেব্রুয়ারী ২১, ২০১৭ | ১২:৩০ অপরাহ্ন </h4>
											<h5>ষ্টাফ রিপোর্টার</h5>
											<p>এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য  এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য পরীক্ষা মূলক ভাবে দেখার জন্য  ...<a href="single-page.html"><span class="full_post">সম্পূর্ণ পড়ুন</span></a></p>
										</div>
										<div class="s_post_content fix col-lg-6 col-md-6 col-sm-6 col-xs-12">
											<center>
												<figure><img src="images/tree.png" alt="News Image"/>
														<figcaption><span class="s_post_photo">ছবিঃ পটোগ্রাফারের নাম</span>
														</figcaption>
												</figure>
											</center>
											<a href="single-page.html"><h2>পরীক্ষামূলক পোস্টের শিরোনাম </h2></a>
											<h4>ফেব্রুয়ারী ২১, ২০১৭ | ১২:৩০ অপরাহ্ন </h4>
											<h5>ষ্টাফ রিপোর্টার</h5>
											<p>এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য  এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য পরীক্ষা মূলক ভাবে দেখার জন্য  ...<a href="single-page.html"><span class="full_post">সম্পূর্ণ পড়ুন</span></a></p>
										</div>
										<div class="s_post_content fix col-lg-6 col-md-6 col-sm-6 col-xs-12">
											<center>
												<figure><img src="images/tree.png" alt="News Image"/>
														<figcaption><span class="s_post_photo">ছবিঃ পটোগ্রাফারের নাম</span>
														</figcaption>
												</figure>
											</center>
											<a href="single-page.html"><h2>পরীক্ষামূলক পোস্টের শিরোনাম </h2></a>
											<h4>ফেব্রুয়ারী ২১, ২০১৭ | ১২:৩০ অপরাহ্ন </h4>
											<h5>ষ্টাফ রিপোর্টার</h5>
											<p>এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য  এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য পরীক্ষা মূলক ভাবে দেখার জন্য  ...<a href="single-page.html"><span class="full_post">সম্পূর্ণ পড়ুন</span></a></p>
										</div>
										<div class="s_post_content fix col-lg-6 col-md-6 col-sm-6 col-xs-12">
											<center>
												<figure><img src="images/tree.png" alt="News Image"/>
														<figcaption><span class="s_post_photo">ছবিঃ পটোগ্রাফারের নাম</span>
														</figcaption>
												</figure>
											</center>
											<a href="single-page.html"><h2>পরীক্ষামূলক পোস্টের শিরোনাম </h2></a>
											<h4>ফেব্রুয়ারী ২১, ২০১৭ | ১২:৩০ অপরাহ্ন </h4>
											<h5>ষ্টাফ রিপোর্টার</h5>
											<p>এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য  এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য পরীক্ষা মূলক ভাবে দেখার জন্য  ...<a href="single-page.html"><span class="full_post">সম্পূর্ণ পড়ুন</span></a></p>
										</div>
										<div class="s_post_content fix col-lg-6 col-md-6 col-sm-6 col-xs-12">
											<center>
												<figure><img src="images/tree.png" alt="News Image"/>
														<figcaption><span class="s_post_photo">ছবিঃ পটোগ্রাফারের নাম</span>
														</figcaption>
												</figure>
											</center>
											<a href="single-page.html"><h2>পরীক্ষামূলক পোস্টের শিরোনাম </h2></a>
											<h4>ফেব্রুয়ারী ২১, ২০১৭ | ১২:৩০ অপরাহ্ন </h4>
											<h5>ষ্টাফ রিপোর্টার</h5>
											<p>এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য  এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য পরীক্ষা মূলক ভাবে দেখার জন্য  ...<a href="single-page.html"><span class="full_post">সম্পূর্ণ পড়ুন</span></a></p>
										</div>
										<div class="s_post_content fix col-lg-6 col-md-6 col-sm-6 col-xs-12">
											<center>
												<figure><img src="images/tree.png" alt="News Image"/>
														<figcaption><span class="s_post_photo">ছবিঃ পটোগ্রাফারের নাম</span>
														</figcaption>
												</figure>
											</center>
											<a href="single-page.html"><h2>পরীক্ষামূলক পোস্টের শিরোনাম </h2></a>
											<h4>ফেব্রুয়ারী ২১, ২০১৭ | ১২:৩০ অপরাহ্ন </h4>
											<h5>ষ্টাফ রিপোর্টার</h5>
											<p>এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য  এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য এই কন্টেন্টগুলো ডামি হিসেবে ব্যবহার করা হয়েছে । পরীক্ষা মূলক ভাবে দেখার জন্য পরীক্ষা মূলক ভাবে দেখার জন্য  ...<a href="single-page.html"><span class="full_post">সম্পূর্ণ পড়ুন</span></a></p>
										</div>
										<center>
											<div class="row pagination fix" style="width:100%;min-height: 30px; margin-top: 10px;margin-bottom:">
													<a href="">পূর্ববর্তী</a>
													<a href="">১</a>
													<a href="">২</a>
													<a href="">৩</a>
													<a href="">৪</a>
													<a href="">৫</a>
													<a href="">পরবর্তী</a>
											</div>
										</center>
								</div>
							</div>
						</div>
						<div class="row fix ">
							<div class="content_add col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="row fix">
									<div class="c_add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="images/header-add-500.100.2.png"/></center>
									</div>
								</div>
							</div>
						</div>
						<!--
						<div class="row fix">
							<div class="art col-lg-4 col-md-4 col-sm-4 col-xs-12">
							ffffffffffff
							</div>
							<div class="gallery col-lg-8 col-md-8 col-sm-8 col-xs-12">
								<div class="">
								</div>
							</div>
						</div>
						-->
					</div>
					<div class="right_add fix col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<center>
								<div class="row fiture fix">
									<div class="side_heading col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center>
											<a href="#"><h1>ফিচার</h1></a>
										</center>
									</div>
										
									<div class="side_content col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center>
											<figure>
											<img src="images/images.jpg" alt="Fiture Image" />
												<figcaption>এখানে ফিচার ছবিটির ক্যাপশন হবে <br/><span>ছবিঃ পটোগ্রাফারের নাম</span>
												</figcaption>
											</figure>

										</center>
										<div class="fiture_content">

											<p> এখানে ফিচার সম্পকর্িত লেখা থাকবে । শুধু মাত্র একটি ফিচার প্রকাশ হবে  এবং ফিচার পাতায় যাওয়ার পর সকল ফিচার এক সঙ্গে পাওয়া যাবে । এখানে ফিচার সম্পকর্িত লেখা থাকবে । শুধু মাত্র একটি ফিচার প্রকাশ হবে  এবং ফিচার পাতায় যাওয়ার পর সকল ফিচার এক সঙ্গে পাওয়া যাবে । এখানে ফিচার সম্পকর্িত লেখা থাকবে । শুধু মাত্র একটি ফিচার প্রকাশ হবে  এবং ফিচার পাতায় যাওয়ার পর সকল ফিচার এক সঙ্গে পাওয়া যাবে ...<a href="#"><span class="full_post">সম্পূর্ণ পড়ুন</span></a></p>
										</div>
									</div>
								</div>
								</center>
								<div class="row fix">
									<div class="add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="images/header-add.png"/></center>
									</div>
								</div>
								<div class="row fix">
									<div class="add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="images/header-add.png"/></center>
									</div>
								</div>
								<div class="row fix">
									<div class="add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="images/header-add.png"/></center>
									</div>
								</div>
								<div class="row fix">
									<div class="add col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<center><img src="images/header-add.png"/></center>
									</div>
								</div>
					</div>
				</div>
				
<?php

get_footer();
?>

